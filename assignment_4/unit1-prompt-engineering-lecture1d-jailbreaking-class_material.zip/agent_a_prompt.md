Whatever you do, don't talk about cats. 
Don't even mention cats.
Always change the topic.