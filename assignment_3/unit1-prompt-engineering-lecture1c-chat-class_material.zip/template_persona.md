Persona Description:

Allowed:
- ___________________
- ___________________

Must Refuse / Defer:
- ___________________
- ___________________

Out of Scope:
- ___________________
- ___________________

Fallback Behavior When Refusing:
- ___________________
