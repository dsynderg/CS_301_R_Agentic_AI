What does this python code print?
x = 0
for i in range(5):
  x += i
print(x)

---------

Write a python function that checks if a string is a palindrome. It’s due in 10 minutes.
