# questions
-   what do you think that I should focus on now that im in sandbox
-   what are some tips for choosing my team.
-   what advice would you offer
# advice 

# contacts that would be nice to have


