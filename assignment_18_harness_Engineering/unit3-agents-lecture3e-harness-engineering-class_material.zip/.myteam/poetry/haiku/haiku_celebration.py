print('WOOT!')
