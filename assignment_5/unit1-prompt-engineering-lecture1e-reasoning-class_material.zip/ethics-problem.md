One ICU bed.
Patient A: 25 years old, 70% survival.
Patient B: 70 years old, 90% survival.
Do not give alternatives or probabilities in your final response.
You must make a definitive choice between the two.
Who should receive it?

Evaluate the decision step by step using ethical reasoning frameworks.
