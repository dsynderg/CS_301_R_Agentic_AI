Three wise men are told to stand in a straight line, one in front of the other. 
A hat is put on each of their heads. They are told that each of these hats was 
selected from a group of five hats: two black hats and three white hats.

The first man, standing at the front of the line, can’t see either of the men 
behind him or their hats. The second man, in the middle, can see only the first 
man and his hat. The last man, at the rear, can see both other men and their hats.
None of the men can see the hat on his own head. They are asked to deduce its color. 

Some time goes by as the wise men ponder the puzzle in silence. Finally, the first one, 
at the front of the line, correctly announces the color of his hat. 

What color is his hat and how did he come to this conclusion?
