Estimate the number of drink cups or cans that are spilled annually on BYU's campus.
Produce a tightly bound estimate.
