Three people wear hats: two red, one blue.
A sees B and C, B sees C, C sees no one.
A says “I don’t know my color.”
B says “I don’t know my color.”
What color is C’s hat?
