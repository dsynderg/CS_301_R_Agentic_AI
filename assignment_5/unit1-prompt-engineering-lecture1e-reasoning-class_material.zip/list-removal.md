In the given list, determine whether it is possible to remove at most one element so the list becomes strictly increasing.
Explain your reasoning.

[1, 5, 3, 4]
